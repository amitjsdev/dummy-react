import React from 'react';

function Contact (){
return <address>
			Public You can find us here:<br />
			
		</address>
}

export default Contact;
