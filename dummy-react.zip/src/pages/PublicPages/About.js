import React from 'react';

const About =()=>{
	return <div>
		<h2>This is Public pages</h2>
		Read more about us at :
	</div>
}
export default About;
