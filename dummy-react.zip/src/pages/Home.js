import React from 'react';
function Home (){
	console.log('Homw');
	return <h1>Welcome to the world!</h1>
}
export default Home;
